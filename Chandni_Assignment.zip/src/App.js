import logo from './logo.svg';
import './App.css';
import Main from './component/main/main';
import Main2 from './component/main2';

function App() {
  return (
    <Main2/>
   
    
  );
}

export default App;
